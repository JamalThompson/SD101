function playGuessMyNumber(){

}
